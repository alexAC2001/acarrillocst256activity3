<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\CustomerModel;
use App\Services\Business\SecurityService;

class OrderController extends Controller
{
    
    // to obtain an instance of the current HTTP request from a post
    public function index(Request $request)
    {
        // Added for Activity 3
        // Put customer data in a model
        //$customerData = new CustomerModel($request->input('firstName'), $request->input('lastName'));
        $customerData = new CustomerModel(request()->get('firstName'), request()->get('lastName'));
        
        // 2 different ways . . .
        // Since we are not using a model
        $product = request()->get('product');
        // This is more efficient since it is not caling a method
        $customerID = $request->input('customerID');

        // Instantiate the Business Logic Layer
        $serviceCustomer = new SecurityService();
        // Pass all customerData to the Business Layer
        $isValid = $serviceCustomer->addAllInformation($product, $customerID, $customerData);
        
        // Determine which view to display
        if($isValid)
        {
            echo("Order Data Committed Successfully");
        }
        else 
        {
            echo("Order Data Was Rolled Back");            
        }        
        return view('order');
    }    
    
    // Validation added for Activity3
    private function validateForm(Request $request)
    {
        // Setup Data Validatoin Rules for Login Form
        $rules = ['user_name'=> 'Required | Between: 4, 10 | Alpha',
                    'password' => 'Required | Between 4, 10'];
        // Run Data Validation Rules
        $this->validate($request, $rules);
    }    
}