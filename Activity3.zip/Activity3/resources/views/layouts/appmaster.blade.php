@include('layouts.header')

<div align="center">
	@yield('content')
</div>
@include('layouts.footer')

